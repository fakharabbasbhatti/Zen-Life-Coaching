import React from 'react'
import Hero from '../components/ConsultingCop/Hero';
import Cards from '../components/ConsultingCop/Cards';

const Consulting = () => {
  return (
    <div>
     <Hero/>
     <Cards/>
    </div>
  )
}

export default Consulting;