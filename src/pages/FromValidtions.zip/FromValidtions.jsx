import React from 'react'
import Form from '../components/FromValidtion/Form';



const FromValidtions = () => {
  return (
    <div>
       <Form/>
       
    </div>
  )
}

export default FromValidtions;